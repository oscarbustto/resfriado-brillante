document.addEventListener("DOMContentLoaded", () => {
  const fonts = ["Arial", "Verdana", "Times New Roman", "Georgia"];
  const fontSelect = document.getElementById("fontName");
  fonts.forEach(f => {
    let option = document.createElement("option");
    option.value = option.innerText = f;
    fontSelect.appendChild(option);
  });
  fontSelect.onchange = () => document.execCommand("fontName", false, fontSelect.value);

  const sizes = [1,2,3,4,5,6,7];
  const sizeSelect = document.getElementById("fontSize");
  sizes.forEach(s => {
    let option = document.createElement("option");
    option.value = option.innerText = s;
    sizeSelect.appendChild(option);
  });
  sizeSelect.onchange = () => document.execCommand("fontSize", false, sizeSelect.value);
});

function format(command) {
  document.execCommand(command, false, null);
}
function toggleDarkMode() {
  document.body.classList.toggle("dark");
}
function downloadFile() {
  const content = document.getElementById("editor").innerHTML;
  const blob = new Blob([content], {type: "text/html"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "documento.html";
  a.click();
  URL.revokeObjectURL(url);
}

// PWA
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("service-worker.js");
}
